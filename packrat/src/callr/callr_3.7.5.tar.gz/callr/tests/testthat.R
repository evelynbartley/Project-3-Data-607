library(testthat)
library(callr)

test_check("callr")
