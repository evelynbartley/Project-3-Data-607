# invalid shape names raise an error

    Shape aesthetic contains invalid value: "void".

---

    Shape names must be given unambiguously.
    i Fix "tri".

