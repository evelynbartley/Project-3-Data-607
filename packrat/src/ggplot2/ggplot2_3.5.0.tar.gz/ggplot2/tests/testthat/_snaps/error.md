# various misuses of +.gg (#2638)

    Cannot use `+` with a single argument.
    i Did you accidentally put `+` on a new line?

---

    Cannot add <ggproto> objects together.
    i Did you forget to add this object to a <ggplot> object?

