# names of values used in manual scales

    No shared levels found between `names(values)` of the manual scale and the data's colour values.

